The Project Studio — Under Construction page
--------------------------------------------
Files:
- index.html  (exactly as provided)
- robots.txt  (allows all)

How to deploy quickly:
- Netlify: drag this folder (or the ZIP) to app.netlify.com → Sites → Add new site from drag & drop.
- Vercel: import as a project, set "Framework Preset: Other".
- cPanel/Hosting: upload index.html to the document root (usually public_html/).